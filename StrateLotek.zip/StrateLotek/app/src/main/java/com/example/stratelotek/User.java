package com.example.stratelotek;

public class User {
    private String name;
    private double x;
    private double y;

    public void setName(String name){
        this.name = name;
    }
    public String getName(){
        return name;
    }
    public void setX(double x){
        this.x = x;
    }
    public double getX(){ return x; }
    public void setY(double y){
        this.y = y;
    }
    public double getY(){
        return y;
    }

    public User(String name){
        this.name = name;
    }

    public User(String name, double x, double y){
        this.name = name;
        this.x = x;
        this.y = y;
        MainActivity.currentUserName = name;
    }
}
