package com.example.stratelotek;


import java.util.ArrayList;

public class PrivateGroup extends PublicGroup {
    public static int privateGroupCounter;
    private int usersCounter;
    private String password;
    private ArrayList<User> userListP = new ArrayList<User>();
    public PrivateGroup(String name, String password) throws BlankPasswordException{
        super(name);
        if(password.equals("")){
            throw new BlankPasswordException("Please fill the password field.");
        }
//        addUser(new User("user6p"), "abc");
//        addUser(new User("user7p"), "abc");
//        addUser(new User("user8p"), "abc");
//        addUser(new User("user9p"), "abc");
//        addUser(new User("user10p"), "abc");
        publicGroupCounter--;
        privateGroupCounter++;
        this.password = password;
    }
    public String getPassword(){
        return password;
    }

    @Override
    public boolean addUser(User user) throws SameNameUserException{
        boolean isAdded = true;
        for(User u:userListP){
            if(u.getName().equals(user.getName()) && !userListP.isEmpty()){
                isAdded = false;
                throw new SameNameUserException("User with same name is present in the group, please change your name.");
            }
        }
        if(isAdded){
            userListP.add(user);
            usersCounter++;
        }
        return isAdded;
    }

    public boolean addUser(User user, String password) throws SameNameUserException, WrongPasswordException{
        boolean isAdded = true;
        if(!getPassword().equals(password)){
            isAdded = false;
            throw new WrongPasswordException("Wrong password.");
        }
        for(User u:userListP){
            if(u.getName().equals(user.getName())){
                isAdded = false;
                throw new SameNameUserException("User with same name is present in the group, please change your name.");
            }
        }
        if(isAdded){
            userListP.add(user);
            usersCounter++;
        }
        return isAdded;
    }
    @Override
    public void destroyGroup(){
        userListP.removeAll(userListP);
        privateGroupCounter--;
    }
    @Override
    public boolean isEmpty(){
        if(userListP.isEmpty()){
            return true;
        }else{
            return false;
        }
    }
    @Override
    public ArrayList<User> getUserList(){
        return userListP;
    }

    @Override
    public ArrayList<String> getUserNames(){
        ArrayList<String> list = new ArrayList<String>();
        for(User u : userListP){
            list.add(u.getName());
        }
        return list;
    }
}
