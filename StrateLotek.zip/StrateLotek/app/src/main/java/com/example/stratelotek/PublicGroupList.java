package com.example.stratelotek;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class PublicGroupList {
    public ArrayList<PublicGroup> groupList = new ArrayList<PublicGroup>();

    public boolean addGroup(PublicGroup group, User user) throws SameGroupNameException{
        boolean isAdded = true;
        for(PublicGroup g:groupList){
            if(g.getName().equals(group.getName())){
                isAdded = false;
                throw new SameGroupNameException("Group with this name exists, please select another name.");
            }
        }
        group.addUser(user);
        if(isAdded){
            groupList.add(group);
        }
        return isAdded;
    }

    public boolean addGroup(PublicGroup group) throws SameGroupNameException{
        boolean isAdded = true;
        for(PublicGroup g:groupList){
            if(g.getName().equals(group.getName())){
                isAdded = false;
                throw new SameGroupNameException("Group with this name exists, please select another name.");
            }
        }
        if(isAdded){
            groupList.add(group);
        }
        return isAdded;
    }

    public void removeGroup(PublicGroup group){
        groupList.remove(group);
    }

    public ArrayList<PublicGroup> getGroupList(){
        return groupList;
    }
    public List<String> getNamesOfGroups(){
        List<String> namesList = new ArrayList<String>();
        for(PublicGroup name:groupList){
            namesList.add(name.getName());
        }
        return namesList;
    }
    public void tryToDestroyGroup(){
        groupList.removeIf(g -> g.isEmpty());
    }
//
//    public static Predicate<PublicGroup> isPublicGroupEmpty()
//    {
//        return p -> p.getUserList().isEmpty();
//    }

    public static Predicate<PrivateGroup> isPrivateGroupEmpty()
    {
        return p -> p.getUserList().isEmpty();
    }

    public ArrayList<PublicGroup> getGroups(){
        return groupList;
    }
}
