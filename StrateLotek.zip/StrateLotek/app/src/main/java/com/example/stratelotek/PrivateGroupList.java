package com.example.stratelotek;

import java.util.ArrayList;
import java.util.List;

public class PrivateGroupList extends PublicGroupList {
    public ArrayList<PrivateGroup> groupList = new ArrayList<PrivateGroup>();

    public ArrayList<PrivateGroup> getPrivateGroups(){
        return this.groupList;
    }

    public boolean addGroup(PrivateGroup group, User u) throws SameGroupNameException{
        boolean isAdded = true;
        for(PrivateGroup g:this.groupList){
            if(g.getName().equals(group.getName())){
                isAdded = false;
                throw new SameGroupNameException("Group with this name exists, please select another name.");
            }
        }
        group.addUser(u, group.getPassword());
        if(isAdded){
            this.groupList.add(group);
        }
        return isAdded;
    }
    public void tryToDestroyGroup(){
        this.groupList.removeIf(g -> g.isEmpty());
    }
    @Override
    public List<String> getNamesOfGroups(){
        List<String> namesList = new ArrayList<String>();
        for(PrivateGroup name:this.groupList){
            namesList.add(name.getName());
        }
        return namesList;
    }

}
