package com.example.stratelotek;

import java.util.ArrayList;

public class PublicGroup {
    public static int publicGroupCounter;
    private int usersCounter;
    private String name;
    private ArrayList<User> userList = new ArrayList<User>();

    public PublicGroup(String name) throws BlankNameException{
        if(name.equals("")){
            throw new BlankNameException("Please enter the group name.");
        }
        this.name = name;
//        addUser(new User("user1"));
//        addUser(new User("user2"));
//        addUser(new User("user3"));
//        addUser(new User("user4"));
//        addUser(new User("user5"));
        publicGroupCounter++;
    }

    public boolean addUser(User user) throws SameNameUserException{
        boolean isAdded = true;
        for(User u:userList){
            if(u.getName().equals(user.getName()) && !userList.isEmpty()){
                isAdded = false;
                throw new SameNameUserException("User with same name is present in the group, please change your name.");
            }
        }
        if(isAdded){
            userList.add(user);
            usersCounter++;
        }
        return isAdded;
    }

    public void removeUser(User user){
        userList.removeIf(u -> u.getName().equals(user.getName()));
        usersCounter--;
    }

//    public boolean tryToDestroy(){
//        if(usersCounter < 1){
//            destroyGroup();
//            return true;
//        }else{
//            return false;
//        }
//    }
    public String getName(){
        return name;
    }

    public void destroyGroup(){
        userList.removeAll(userList);
        publicGroupCounter--;
    }

    public ArrayList<User> getUserList(){
        return userList;
    }

    public ArrayList<String> getUserNames(){
        ArrayList<String> list = new ArrayList<String>();
        for(User u : userList){
            list.add(u.getName());
        }
        return list;
    }

    public boolean isEmpty(){
        if(userList.isEmpty()){
            return true;
        }else{
            return false;
        }
    }
}
