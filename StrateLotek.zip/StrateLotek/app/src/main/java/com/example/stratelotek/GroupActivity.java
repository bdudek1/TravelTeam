package com.example.stratelotek;

import android.content.Context;
import android.content.Intent;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.stratelotek.ui.group.GroupFragment;
import com.google.android.gms.maps.MapView;

import java.util.ArrayList;
import java.util.List;

public class GroupActivity extends AppCompatActivity implements RecyclerViewAdapter.ItemClickListener{

    static Context context;
    private SectionsPagerAdapter mSectionsPagerAdapter;
    private ViewPager mViewPager;
    static RecyclerViewAdapter.ItemClickListener listenerContext;
    static BottomNavigationView navigation;
    static TextView tytul;
    static TextView nazwaGrupy;
    static EditText messageEtext;
    static FloatingActionButton sendButton;
    static RecyclerView chat;
    static RecyclerView listaUzytkownikow;
    static RecyclerViewAdapter adapter;
    static RecyclerViewAdapter adapterChat;
    static List<String> messages;
    static MapView mapView;

    public class SectionsPagerAdapter extends FragmentPagerAdapter{

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {

            return PlaceholderFragment.newInstance(position + 1);
        }

        @Override
        public int getCount() {
            // Show 3 total pages.
            return 3;
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.group_activity);
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container_group, GroupFragment.newInstance())
                    .commitNow();
        }

        context = getApplicationContext();
        messages = new ArrayList<>();

        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager)findViewById(R.id.container_group);
        mViewPager.setAdapter(mSectionsPagerAdapter);

    }
    public static class PlaceholderFragment extends Fragment {
        /**
         * The fragment argument representing the section number for this
         * fragment.
         */
        private static final String ARG_SECTION_NUMBER = "section_number";

        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        public static PlaceholderFragment newInstance(int sectionNumber) {
            PlaceholderFragment fragment = new PlaceholderFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);
            return fragment;
        }

        public PlaceholderFragment() {

        }

        @Override
        public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            final View rootView = inflater.inflate(R.layout.group_fragment, container, false);

            mapView = rootView.findViewById(R.id.map);
            navigation = rootView.findViewById(R.id.bottomNavigationInGroup);
            navigation.setSelectedItemId(R.id.users_list);
            FunHolder.adjustGravity(navigation);
            navigation.setOnClickListener(null);
            messageEtext = rootView.findViewById(R.id.sendMessage);
            sendButton = rootView.findViewById(R.id.sendButton);
            chat = rootView.findViewById(R.id.recyclerChat);
            tytul = rootView.findViewById(R.id.textTitle);
            tytul.setTextSize(32);
            nazwaGrupy = rootView.findViewById(R.id.groupName);
            nazwaGrupy.setTextSize(32);
            nazwaGrupy.setText(MainActivity.groupName);
            listaUzytkownikow = rootView.findViewById(R.id.recyclerUsersList);
            chat = rootView.findViewById(R.id.recyclerChat);
            listaUzytkownikow.setLayoutManager(new LinearLayoutManager(context));
            chat.setLayoutManager(new LinearLayoutManager(context));
            adapter = new RecyclerViewAdapter(context, new ArrayList<String>());
            adapterChat = new RecyclerViewAdapter(context, new ArrayList<String>());
            adapter.setClickListener(listenerContext);
            adapterChat.setClickListener(listenerContext);
            listaUzytkownikow.setAdapter(adapter);
            DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(listaUzytkownikow.getContext(),
                    getResources().getConfiguration().orientation);
            listaUzytkownikow.addItemDecoration(dividerItemDecoration);


            for (int i = 0; i < navigation.getMenu().size(); i++) {
                navigation.getMenu().getItem(i).setEnabled(false);
            }

            sendButton.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    messageEtext = rootView.findViewById(R.id.sendMessage);
                    messageEtext.invalidate();
                    if(messageEtext.getText().toString().equals("")){
                        Toast.makeText(context, "Please enter message.", Toast.LENGTH_SHORT).show();
                    }else{
                        messages.add(MainActivity.user.getName() +": "+messageEtext.getText().toString());
                        adapterChat = new RecyclerViewAdapter(context, messages);
                        adapterChat.setClickListener(listenerContext);
                        adapterChat.notifyDataSetChanged();
                        chat.setAdapter(adapterChat);
                        chat.invalidate();
                    }
                }
            });


            switch (getArguments().getInt(ARG_SECTION_NUMBER)) {
                case 1: {
                    FunHolder.initUsersList();
                    navigation.setSelectedItemId(R.id.users_list);
                    tytul.setText("Users list");
                    listaUzytkownikow.setLayoutManager(new LinearLayoutManager(context));
                    if(MainActivity.isPublic){
                        adapter = new RecyclerViewAdapter(context, MainActivity.publicGroupList.getGroups().get(MainActivity.publicGroupList.getNamesOfGroups().indexOf(MainActivity.groupName)).getUserNames());
                    }else{
                        adapter = new RecyclerViewAdapter(context, MainActivity.privateGroupList.getPrivateGroups().get(MainActivity.privateGroupList.getNamesOfGroups().indexOf(MainActivity.groupName)).getUserNames());
                    }
                    adapter.setClickListener(listenerContext);
                    adapter.notifyDataSetChanged();
                    listaUzytkownikow.setAdapter(adapter);
                    listaUzytkownikow.invalidate();
                    break;
                }
                case 2: {
                    FunHolder.initMap();
                    navigation.setSelectedItemId(R.id.map);
                    tytul.setText("Map");
                    break;
                }
                case 3: {
                    FunHolder.initChat();
                    adapterChat = new RecyclerViewAdapter(context, messages);
                    adapterChat.setClickListener(listenerContext);
                    adapterChat.notifyDataSetChanged();
                    chat.setAdapter(adapterChat);
                    chat.invalidate();
                    navigation.setSelectedItemId(R.id.chat);
                    tytul.setText("Chat");
                    break;
                }

            }
            return rootView;


        }
    }
    @Override
    public void onItemClick(View view, int position) {

    }
    @Override
    public void onBackPressed() {
        if(MainActivity.isPublic){
            MainActivity.publicGroupList.getGroups().get(MainActivity.publicGroupList.getNamesOfGroups().indexOf(MainActivity.groupName)).getUserList().removeIf(x -> x.getName().equals(MainActivity.user.getName()));
            MainActivity.publicGroupList.tryToDestroyGroup();
        }else{
            MainActivity.privateGroupList.getPrivateGroups().get(MainActivity.privateGroupList.getNamesOfGroups().indexOf(MainActivity.groupName)).getUserList().removeIf(x -> x.getName().equals(MainActivity.user.getName()));
            MainActivity.privateGroupList.tryToDestroyGroup();
        }
        MainActivity.currentUserName = MainActivity.user.getName();
        MainActivity.userName.setText(MainActivity.currentUserName);
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
