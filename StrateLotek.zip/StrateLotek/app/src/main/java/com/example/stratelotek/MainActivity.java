package com.example.stratelotek;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

final public class MainActivity extends AppCompatActivity implements RecyclerViewAdapter.ItemClickListener {
    static TextView informacje;
    static TextView wprowadzNick;
    static TextView typGrupy;
    static Button szukajDruzyny;
    static Button stworzDruzyne;
    static Button zmienNick;
    static Button buttonInfo;
    static SeekBar zasiegBar;
    static Context context;
    static RecyclerView listaGrup;
    static RecyclerView listaGrupPrywatnych;
    static BottomNavigationView navigation;
    static RecyclerViewAdapter.ItemClickListener listenerContext;
    static RecyclerViewAdapter adapter;
    static RecyclerViewAdapter adapterPrywatnych;
    static PublicGroupList publicGroupList = new PublicGroupList();
    static PrivateGroupList privateGroupList = new PrivateGroupList();
    static String groupName;
    static boolean isPublic;
    static boolean isInPublicSection = false;
    public static User user;
    static TextView userName;
    static String currentUserName = "User";
     /**
     * The {@link android.support.v4.view.PagerAdapter} that will provide
     * fragments for each of the sections. We use a
     * {@link FragmentPagerAdapter} derivative, which will keep every
     * loaded fragment in memory. If this becomes too memory intensive, it
     * may be best to switch to a
     * {@link android.support.v4.app.FragmentStatePagerAdapter}.
     */
    private SectionsPagerAdapter mSectionsPagerAdapter;

    /**
     * The {@link ViewPager} that will host the section contents.
     */
    private ViewPager mViewPager;



    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = getApplicationContext();
        listenerContext = this;

        user = new User(currentUserName);



        //Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);
        // Create the adapter that will return a fragment for each of the three
        // primary sections of the activity.
        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.container);
        mViewPager.setAdapter(mSectionsPagerAdapter);


        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {

            // This method will be invoked when a new page becomes selected.
            @Override
            public void onPageSelected(int position) {
                switch(position){
                    case 0:{
//                        navigation.setSelectedItemId(R.id.home);
                        break;
                    }
                    case 1:{
//                        navigation.setSelectedItemId(R.id.public_groups);
                        isInPublicSection = true;
                        Toast.makeText(MainActivity.this,
                                "In public: " + isInPublicSection, Toast.LENGTH_SHORT).show();
                        break;
                    }
                    case 2:{
//                        navigation.setSelectedItemId(R.id.private_groups);
                        isInPublicSection = false;
                        Toast.makeText(MainActivity.this,
                                "In public: " + isInPublicSection, Toast.LENGTH_SHORT).show();
                        break;
                    }
                }
            }

            // This method will be invoked when the current page is scrolled
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            // Called when the scroll state changes:
            // SCROLL_STATE_IDLE, SCROLL_STATE_DRAGGING, SCROLL_STATE_SETTLING
            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
      
    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

        return super.onOptionsItemSelected(item);
    }


  

    /**
     * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
     * one of the sections/tabs/pages.
     */
    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {

            return PlaceholderFragment.newInstance(position + 1);
        }

        @Override
        public int getCount() {
            // Show 3 total pages.
            return 3;
        }

    }

    /**
     * A placeholder fragment containing a simple view.
     */
    public static class PlaceholderFragment extends Fragment {
        /**
         * The fragment argument representing the section number for this
         * fragment.
         */
        private static final String ARG_SECTION_NUMBER = "section_number";

        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        public static PlaceholderFragment newInstance(int sectionNumber) {
            PlaceholderFragment fragment = new PlaceholderFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);
            return fragment;
        }

        public PlaceholderFragment() {

        }
        TextView dokladnosc;
        @Override
        public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            final View rootView = inflater.inflate(R.layout.fragment_main, container, false);
            userName = rootView.findViewById(R.id.inputNickText);
            userName.setText(user.getName());
//            user = new User(userName.getText().toString());
            listaGrup = rootView.findViewById(R.id.groupList);
            listaGrup.setLayoutManager(new LinearLayoutManager(context));
            adapter = new RecyclerViewAdapter(context, new ArrayList<String>());
            adapter.setClickListener(listenerContext);
            listaGrup.setAdapter(adapter);
            DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(listaGrup.getContext(),
                    getResources().getConfiguration().orientation);
            listaGrup.addItemDecoration(dividerItemDecoration);

            adapterPrywatnych = new RecyclerViewAdapter(context, new ArrayList<String>());
            adapterPrywatnych.setClickListener(listenerContext);

            navigation = rootView.findViewById(R.id.bottomNavigation);
            navigation.setSelectedItemId(R.id.home);
            FunHolder.adjustGravity(navigation);
            navigation.setOnClickListener(null);

            for (int i = 0; i < navigation.getMenu().size(); i++) {
                navigation.getMenu().getItem(i).setEnabled(false);
            }

            listaGrupPrywatnych = rootView.findViewById(R.id.privateGroupList);
            listaGrupPrywatnych.setLayoutManager(new LinearLayoutManager(context));
            listaGrupPrywatnych.setAdapter(adapterPrywatnych);
            DividerItemDecoration privateDividerItemDecoration = new DividerItemDecoration(listaGrupPrywatnych.getContext(),
                    getResources().getConfiguration().orientation);
            listaGrupPrywatnych.addItemDecoration(privateDividerItemDecoration);

            listaGrup = rootView.findViewById(R.id.groupList);
            typGrupy = (TextView) rootView.findViewById(R.id.lotekName);
            dokladnosc = (TextView) rootView.findViewById(R.id.dokladnosc);
            wprowadzNick = (TextView) rootView.findViewById(R.id.wprowadzNick);
            informacje = (TextView) rootView.findViewById(R.id.opis);
            szukajDruzyny = rootView.findViewById(R.id.seekForTeam);
            stworzDruzyne = rootView.findViewById(R.id.createTeam);
            zmienNick = rootView.findViewById(R.id.buttonChangeName);
            wprowadzNick.setTextSize(32);
            typGrupy.setTextSize(32);
            userName.setTextSize(32);
            dokladnosc.setTextSize(18);
            informacje.setTextSize(16);
            dokladnosc.setText("Range: " + 20 + "km");
            buttonInfo = rootView.findViewById(R.id.buttonInformacje);


            zasiegBar = rootView.findViewById(R.id.rangeBar);
            zasiegBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    dokladnosc.setText("Range: " + seekBar.getProgress() + "km");
                }

                public void onStartTrackingTouch(SeekBar seekBar) {
                    // TODO Auto-generated method stub
                    dokladnosc.setText("Range: " + seekBar.getProgress() + "km");
                }

                public void onStopTrackingTouch(SeekBar seekBar) {
                    dokladnosc.setText("Range: " + seekBar.getProgress() + "km");
                }

            });
            stworzDruzyne.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view)
                {
//                    user.setName(userName.getText().toString());
                    final AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    builder.setMessage(getArguments().getInt(ARG_SECTION_NUMBER) == 2 ? "Create a public group" : "Create a private group").setView(getArguments().getInt(ARG_SECTION_NUMBER) == 2? R.layout.public_group_create : R.layout.private_group_create)
                            .setPositiveButton("Create", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    if(getArguments().getInt(ARG_SECTION_NUMBER) == 2){
                                        Dialog dialogView = (Dialog) dialog;
                                        EditText name = (EditText)dialogView.findViewById(R.id.groupname);
                                        try{
                                            userName = (TextView) rootView.findViewById(R.id.inputNickText);
                                            userName.setText(user.getName());
                                            userName.invalidate();
                                            user.setName(userName.getText().toString());
                                            publicGroupList.addGroup(new PublicGroup(name.getText().toString()), user);
                                            groupName = name.getText().toString();
                                            isPublic = true;
                                            Toast.makeText(context, "Public group list size: "+publicGroupList.getGroups().size(), Toast.LENGTH_SHORT).show();
                                            Toast.makeText(context, "user.getName(): "+user.getName() + ", userName.getText().toString(): " + userName.getText().toString(), Toast.LENGTH_SHORT).show();
                                            changeActivity();
                                        }catch(SameGroupNameException e){

                                        }catch(BlankNameException e){

                                        }


                                    }else if(getArguments().getInt(ARG_SECTION_NUMBER) == 3){
//                                        isInPublicSection = false;
                                        Dialog dialogView = (Dialog) dialog;
                                        EditText name=(EditText)dialogView.findViewById(R.id.groupname);
                                        EditText password=(EditText)dialogView.findViewById(R.id.password);
                                        try{
                                            userName = (TextView) rootView.findViewById(R.id.inputNickText);
                                            userName.setText(user.getName());
                                            userName.invalidate();
                                            user.setName(userName.getText().toString());
                                            privateGroupList.addGroup(new PrivateGroup(name.getText().toString(), password.getText().toString()), user);
                                            groupName = name.getText().toString();
                                            isPublic = false;
                                            Toast.makeText(context, "Private group list size: "+privateGroupList.getPrivateGroups().size(), Toast.LENGTH_SHORT).show();
                                            Toast.makeText(context, "user.getName(): "+user.getName() + ", userName.getText().toString(): " + userName.getText().toString(), Toast.LENGTH_SHORT).show();
                                            changeActivity();
                                        }catch(SameGroupNameException e){

                                        }catch(BlankPasswordException e){

                                        }catch(BlankNameException e){

                                        }

                                    }

                                }
                            })
                            .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {

                                }
                            });
                    // Create the AlertDialog object and return it
                    builder.create();
                    builder.show();
                }

            });

            szukajDruzyny.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view)
                {
                    user.setName(userName.getText().toString());
                    switch(getArguments().getInt(ARG_SECTION_NUMBER)){
                    case 2:{
                        listaGrup = rootView.findViewById(R.id.groupList);
                        publicGroupsInit();
                        break;
                    }
                        case 3:{
                            listaGrupPrywatnych = rootView.findViewById(R.id.privateGroupList);
                            privateGroupsInit();
                            break;
                        }
                }

                }

            });

            zmienNick.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view)
                {
                    final AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    builder.setMessage("Enter user name:").setView(R.layout.user_name_change)
                            .setPositiveButton("Set name", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) throws BlankNameException {
                                        Dialog dialogView = (Dialog) dialog;
                                        EditText name = (EditText)dialogView.findViewById(R.id.userNameChange);
                                        try{
                                            if(name.getText().toString().equals("")){
                                                throw new BlankNameException("Please enter your nickname");
                                            }else{
                                                userName = (TextView) rootView.findViewById(R.id.inputNickText);
                                                userName.setText(name.getText().toString());
                                                userName.invalidate();
                                                user.setName(name.getText().toString());
                                            }

                                        }catch(BlankNameException e){

                                        }

                                        Toast.makeText(context, "user.getName(): "+user.getName() + ", userName.getText().toString(): " + userName.getText().toString(), Toast.LENGTH_SHORT).show();

                                }
                            })
                            .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {

                                }
                            });
                    // Create the AlertDialog object and return it
                    builder.create();
                    builder.show();
                }

            });

            switch(getArguments().getInt(ARG_SECTION_NUMBER)){
                case 1:{
                    FunHolder.initInfo();
                    navigation.setSelectedItemId(R.id.home);
                    dokladnosc.setVisibility(View.INVISIBLE);
                    listaGrup.setVisibility(View.INVISIBLE);
                    listaGrupPrywatnych.setVisibility(View.INVISIBLE);
                    break;
                }
                case 2:{
                    FunHolder.initGroups();
                    typGrupy.setText("Public groups");
                    navigation.setSelectedItemId(R.id.public_groups);
                    dokladnosc.setVisibility(View.VISIBLE);
                    listaGrup.setVisibility(View.VISIBLE);
                    listaGrupPrywatnych.setVisibility(View.INVISIBLE);
                    listaGrup = rootView.findViewById(R.id.groupList);
                    publicGroupsInit();
                    break;
                }
                case 3:{
                    FunHolder.initGroups();
                    typGrupy.setText("Private groups");
                    navigation.setSelectedItemId(R.id.private_groups);
                    dokladnosc.setVisibility(View.VISIBLE);
                    listaGrup.setVisibility(View.INVISIBLE);
                    listaGrupPrywatnych.setVisibility(View.VISIBLE);
                    listaGrupPrywatnych = rootView.findViewById(R.id.privateGroupList);
                    privateGroupsInit();
                    break;
                }

            }
            return rootView;


        }



    }
    @Override
    public void onItemClick(View view, int position) {
        if(isInPublicSection){
            publicGroupsInit();
            Toast.makeText(this, "You clicked " + adapter.getItem(position) + " on row number " + position, Toast.LENGTH_SHORT).show();

            for(PublicGroup g : publicGroupList.getGroups()){
                if(g.getName().equals(adapter.getItem(position))){
                    try{
                        user.setName(userName.getText().toString());
                        if(g.addUser(user)){
                            groupName = g.getName();
                            isPublic = true;
                            Toast.makeText(context, "Public group list size: "+publicGroupList.getGroups().size(), Toast.LENGTH_SHORT).show();
                            changeActivity();
                        }

                    }catch (SameNameUserException e){

                    }

                }
            }
        }else{
            privateGroupsInit();
            //Toast.makeText(this, "You clicked " + adapterPrywatnych.getItem(position) + " on row number " + position, Toast.LENGTH_SHORT).show();
            final AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Enter password").setView(R.layout.private_group_enter)
                    .setPositiveButton("Enter", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            Dialog dialogView = (Dialog) dialog;
                            EditText password=(EditText)dialogView.findViewById(R.id.passwordEntry);
                            Toast.makeText(context, "Private group list size: "+privateGroupList.getPrivateGroups().size(), Toast.LENGTH_SHORT).show();
                            for(PrivateGroup g : privateGroupList.getPrivateGroups()){
                                Toast.makeText(context, "true: " + g.getName().equals(adapterPrywatnych.getItem(position)) , Toast.LENGTH_SHORT).show();
                                if(g.getName().equals(adapterPrywatnych.getItem(position))){
                                    try{
                                        user.setName(userName.getText().toString());
                                        if(g.addUser(user, password.getText().toString())){
                                            groupName = g.getName();
                                            isPublic = false;
                                            changeActivity();
                                            //g.getName().equals(adapterPrywatnych.getItem(position))
                                        }

                                    }catch (SameNameUserException e){

                                    }catch (WrongPasswordException e){

                                    }

                                }
                            }
                        }
                    })
                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {

                        }
                    });
            builder.create();
            builder.show();

        }

    }

    private static void publicGroupsInit(){
        listaGrup.setLayoutManager(new LinearLayoutManager(context));
        adapter = new RecyclerViewAdapter(context, publicGroupList.getNamesOfGroups());
        adapter.setClickListener(listenerContext);
        adapter.notifyDataSetChanged();
        listaGrup.setAdapter(adapter);
        listaGrup.invalidate();
    }

    private static void privateGroupsInit(){
        listaGrupPrywatnych.setLayoutManager(new LinearLayoutManager(context));
        adapterPrywatnych = new RecyclerViewAdapter(context, privateGroupList.getNamesOfGroups());
        adapterPrywatnych.setClickListener(listenerContext);
        adapterPrywatnych.notifyDataSetChanged();
        listaGrupPrywatnych.setAdapter(adapterPrywatnych);
        listaGrupPrywatnych.invalidate();
    }

    private static void changeActivity() {
        Intent myIntent = new Intent(context, GroupActivity.class);
        context.startActivity(myIntent);
        //finish();
    }
}

