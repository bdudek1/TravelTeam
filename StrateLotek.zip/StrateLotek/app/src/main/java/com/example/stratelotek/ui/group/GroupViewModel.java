package com.example.stratelotek.ui.group;

import android.arch.lifecycle.ViewModel;

public class GroupViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
